# memo.extraction
