# memo.lifecycle
