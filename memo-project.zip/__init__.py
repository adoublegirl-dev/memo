# memo.core
