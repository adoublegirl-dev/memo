# memo.retrieval
